# Asteroids Reloaded
This is a non-commecrtial project
HTML5 and JS based version of one of my favourite games during my childhood, asteroids.
